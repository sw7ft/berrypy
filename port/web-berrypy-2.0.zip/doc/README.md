# BerryPy - BlackBerry App Platform Manager

**Version:** 2.0  
**Category:** Web Application Manager  
**Author:** SW7FT

## Overview

BerryPy is a full-featured application manager designed specifically for BlackBerry 
devices running BB10/QNX systems. Manage, install, and monitor all your Python web 
applications from one beautiful, unified interface.

## Installation

```bash
# Install BerryPy (requires Python port)
qpkg install berrypy

# Start BerryPy
berrypy start

# Access the web interface
# Open browser to: http://127.0.0.1:8001
```

## Usage

### Starting BerryPy
```bash
berrypy start     # Start the server
berrypy           # Same as start
```

### Stopping BerryPy
```bash
berrypy stop      # Stop the server
```

### Other Commands
```bash
berrypy restart   # Restart the server
berrypy status    # Check if running
berrypy logs      # View recent logs
berrypy url       # Show access URL
```

## Features

- **App Management** - Start, stop, and monitor running applications
- **App Installation** - Install web apps from the BerryPy store
- **Auto-Start Config** - Configure apps to launch on boot
- **Beautiful UI** - Dark purple theme optimized for BlackBerry
- **Process Detection** - Automatic detection of running apps
- **Port Management** - Smart port detection and display

## Requirements

- Python 3.11+ (install via: `qpkg install python`)
- Flask (will be installed automatically)

## Auto-Start on Boot (Optional)

To start BerryPy automatically when your device boots:

1. Edit your `~/.profile`:
```bash
nano ~/.profile
```

2. Add this line at the end:
```bash
berrypy start >/dev/null 2>&1 &
```

3. Save and exit (Ctrl+O, Enter, Ctrl+X)

## Accessing BerryPy

After starting BerryPy, open your BlackBerry browser and navigate to:
```
http://127.0.0.1:8001
```

You can also add this to your home screen for quick access!

## Troubleshooting

### BerryPy won't start
```bash
# Check logs
berrypy logs

# Try stopping and restarting
berrypy stop
berrypy start
```

### Port 8001 already in use
```bash
# Check what's using the port
netstat -an | grep 8001

# Stop the conflicting process
berrypy stop
```

### Python not found
```bash
# Install Python port
qpkg install python

# Verify installation
which python3
python3 --version
```

## Files and Directories

- **Binary:** `$NATIVE_TOOLS/bin/berrypy`
- **Application:** `$NATIVE_TOOLS/share/berrypy/`
- **Logs:** `$NATIVE_TOOLS/share/berrypy/berrypy.log`
- **PID File:** `$NATIVE_TOOLS/share/berrypy/berrypy.pid`

## Support

For issues, updates, or feature requests:
- Visit: https://berrystore.sw7ft.com
- GitHub: https://github.com/sw7ft/BerryPy

## License

Developed by SW7FT for the BlackBerry community.

---

**Made with 💜 for BlackBerry users everywhere**
